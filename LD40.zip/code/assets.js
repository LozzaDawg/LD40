
var angel1img = new Image()
angel1img.src = 'assets/angel1.png'
var demon1img = new Image()
demon1img.src = 'assets/demon1.png'
